import slideImg from "./../assets/images/Layer 1.png";

export const HeroSliderData = [
  {
    id: 1,
    img: slideImg,
  },
  {
    id: 2,
    img: slideImg,
  },
  {
    id: 3,
    img: slideImg,
  },
  {
    id: 4,
    img: slideImg,
  },
  {
    id: 5,
    img: slideImg,
  },
  {
    id: 6,
    img: slideImg,
  },
];
