import React from "react";
import HeroSection from "./HomeContainer/HeroSection";

const HomePage = () => {
  return (
    <>
      <HeroSection />
    </>
  );
};

export default HomePage;
