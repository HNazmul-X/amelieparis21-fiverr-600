import React from "react";
import ProfileCreationMain from "../../components/ProfileCreationMain";

const ProfileCreation = () => {
    return (
        <>
            <ProfileCreationMain/>
        </>
    );
};

export default ProfileCreation;
